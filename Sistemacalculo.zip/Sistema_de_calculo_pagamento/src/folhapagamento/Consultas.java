package folhapagamento;

import java.util.ArrayList;

public class Consultas {

    public Funcionario buscarFuncionario(
            ArrayList<Funcionario> funcionarios, int matriculaBusca) {

        for (int i = 0; i < funcionarios.size(); i++) {

            if (funcionarios.get(i).getMatricula() == matriculaBusca) {

                return funcionarios.get(i);
            }
        }

        return null;
    }

    public void listarFuncionarios(
            ArrayList<Funcionario> funcionarios) {

        if (funcionarios.isEmpty()) {

            System.out.println("Nenhum funcionário cadastrado.");

        } else {

            for (int i = 0; i < funcionarios.size(); i++) {

                System.out.println("-------------------------");

                System.out.println("Nome: "
                        + funcionarios.get(i).getNome());

                System.out.println("Matrícula: "
                        + funcionarios.get(i).getMatricula());

                System.out.println("Cargo: "
                        + funcionarios.get(i).getCargo());

                System.out.printf("Salário: R$ %.2f%n",
                        funcionarios.get(i).getSalarioBase());
            }
        }
    }
}
