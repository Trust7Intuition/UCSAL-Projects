package folhapagamento;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.InputMismatchException;

public class Principal {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);
        ArrayList<Funcionario> funcionarios = new ArrayList<>();

        Cadastro cadastro = new Cadastro();
        Consultas consultas = new Consultas();
        Calculos calculos = new Calculos();
        Relatorio relatorio = new Relatorio();

        int opcao = 0;

        while (opcao != 6) {

            System.out.println("\n==================================");
            System.out.println("    SISTEMA DE FOLHA DE PAGAMENTO");
            System.out.println("==================================");
            System.out.println("1 - Cadastrar funcionário");
            System.out.println("2 - Calcular folha de pagamento");
            System.out.println("3 - Consultar funcionário");
            System.out.println("4 - Listar funcionários");
            System.out.println("5 - Resumo da folha de pagamento");
            System.out.println("6 - Encerrar sistema");
            System.out.println("==================================");
            System.out.print("Escolha uma opção: ");

            try {

                opcao = entrada.nextInt();
                entrada.nextLine();

                if (opcao == 1) {

                    System.out.print("Nome: ");
                    String nome = entrada.nextLine();

                    System.out.print("Matrícula: ");
                    int matricula = entrada.nextInt();
                    entrada.nextLine();

                    System.out.print("Cargo: ");
                    String cargo = entrada.nextLine();

                    System.out.print("Salário-base: ");
                    double salario = entrada.nextDouble();
                    entrada.nextLine();

                    if (Cadastro.validarNome(nome)
                            && Cadastro.validarSalario(salario)) {

                        Funcionario novoFuncionario =
                                new Funcionario(nome, matricula, cargo, salario);

                        funcionarios.add(novoFuncionario);
                        cadastro.exibirMensagemCadastro();

                    } else {
                        System.out.println("Dados inválidos!");
                    }

                } else if (opcao == 2) {

                    System.out.print("Digite a matrícula: ");
                    int matriculaBusca = entrada.nextInt();
                    entrada.nextLine();

                    Funcionario funcionario =
                            consultas.buscarFuncionario(funcionarios, matriculaBusca);

                    if (funcionario != null) {

                        double salarioBruto =
                                funcionario.calcularSalarioBruto();

                        double salarioLiquido =
                                calculos.calcularSalarioLiquido(salarioBruto);

                        double descontos = salarioBruto - salarioLiquido;

                        relatorio.exibirDemonstrativo(
                                funcionario,
                                salarioBruto,
                                descontos,
                                salarioLiquido
                        );

                    } else {
                        System.out.println("Funcionário não encontrado!");
                    }

                } else if (opcao == 3) {

                    System.out.print("Digite a matrícula: ");
                    int matriculaBusca = entrada.nextInt();
                    entrada.nextLine();

                    Funcionario funcionario =
                            consultas.buscarFuncionario(funcionarios, matriculaBusca);

                    if (funcionario != null) {

                        System.out.println("\n======= DADOS DO FUNCIONÁRIO =======");
                        System.out.println("Nome: " + funcionario.getNome());
                        System.out.println("Matrícula: " + funcionario.getMatricula());
                        System.out.println("Cargo: " + funcionario.getCargo());

                        System.out.printf("Salário: R$ %.2f%n",
                                funcionario.getSalarioBase());

                    } else {
                        System.out.println("Funcionário não encontrado!");
                    }

                } else if (opcao == 4) {

                    consultas.listarFuncionarios(funcionarios);

                } else if (opcao == 5) {

                    double totalSalarios = 0;
                    double totalDescontos = 0;

                    for (int i = 0; i < funcionarios.size(); i++) {

                        double salarioBruto =
                                funcionarios.get(i).calcularSalarioBruto();

                        double liquido =
                                calculos.calcularSalarioLiquido(salarioBruto, 0.0);

                        totalSalarios += salarioBruto;
                        totalDescontos += salarioBruto - liquido;
                    }

                    System.out.println("\n======= RESUMO DA FOLHA =======");
                    System.out.println("Funcionários: " + funcionarios.size());

                    System.out.printf("Total bruto: R$ %.2f%n",
                            totalSalarios);

                    System.out.printf("Total de descontos: R$ %.2f%n",
                            totalDescontos);

                    System.out.printf("Total líquido: R$ %.2f%n",
                            totalSalarios - totalDescontos);

                } else if (opcao == 6) {

                    System.out.println("Sistema encerrado!");

                } else {

                    System.out.println("Opção inválida!");
                }

            } catch (InputMismatchException erro) {

                System.out.println(
                        "Entrada inválida! Digite um valor numérico corretamente."
                );

                entrada.nextLine();
            }
        }

        entrada.close();
    }
}
