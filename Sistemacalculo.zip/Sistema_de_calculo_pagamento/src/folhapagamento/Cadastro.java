package folhapagamento;

public class Cadastro {
	
	public static boolean validarSalario(double valor) {
		
		if (valor > 0) {
			return true;
		} else {
			return false;
		}
	}
	
	public static boolean validarNome(String nomeFuncionario) {
		
		if (nomeFuncionario != null && !nomeFuncionario.trim().isEmpty()) {
			return true;
		} else {
			return false;
		}
	}
	
	public void exibirMensagemCadastro() {
		System.out.println("Funcionario cadastro com sucesso!");
	}
}
