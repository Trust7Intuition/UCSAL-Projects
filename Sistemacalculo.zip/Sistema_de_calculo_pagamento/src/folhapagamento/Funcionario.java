package folhapagamento;

public class Funcionario {
	
	private String nome;
	private int matricula;
	private String cargo;
	private double salarioBase;
	
public Funcionario(String n, int m, String c, double s) {
	nome = n;
	matricula = m;
	cargo = c;
	salarioBase = s;
	
	}

	public String getNome() {
		return nome;
	}
	
	public int getMatricula() {
		return matricula;
	}
	
	public String getCargo() {
		return cargo;
	}
	
	public double getSalarioBase() {
		return salarioBase;
	}
	
	public double calcularSalarioBruto() {
		return salarioBase;
	}
}
