package folhapagamento;

public class Relatorio {
	 public void exibirDemonstrativo (Funcionario funcionario, double salarioBruto, double descontos, double salarioLiquido) {

	        System.out.println("\n==================================");
	        System.out.println("     DEMONSTRATIVO DE PAGAMENTO");
	        System.out.println("==================================");

	        System.out.println("Funcionário: " + funcionario.getNome());
	        System.out.println("Matrícula: " + funcionario.getMatricula());
	        System.out.println("Cargo: " + funcionario.getCargo());

	        System.out.printf("Salário bruto: R$ %.2f%n", salarioBruto);
	        System.out.printf("Descontos: R$ %.2f%n", descontos);
	        System.out.printf("Salário líquido: R$ %.2f%n", salarioLiquido);

	        System.out.println("==================================");
	    }
}
