package folhapagamento;

public class Calculos {
	public double calcularSalarioLiquido(double salarioBruto) {

        double desconto = salarioBruto * 0.10;

        return salarioBruto - desconto;
    }

    public double calcularSalarioLiquido(
            double salarioBruto, double outrosDescontos) {

        double desconto = salarioBruto * 0.10;

        return salarioBruto - desconto - outrosDescontos;
    }

}
